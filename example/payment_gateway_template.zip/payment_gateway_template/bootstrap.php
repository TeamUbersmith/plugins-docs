<?php

namespace UbersmithPlugin\PaymentGatewayTemplate;

require_once 'transaction/class.credit_card.php';
require_once 'transaction/class.ach.php';
require_once 'transaction/class.ipn.php';
